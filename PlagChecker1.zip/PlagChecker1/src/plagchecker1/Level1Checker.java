/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package plagchecker1;

/**
 *
 * @author saad
 */
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

/**
 *
 * @author saad
 */
public class Level1Checker extends Comparer{
    public void commentExtractor(File input) throws IOException
    {
        super.pFile[0]= new FileWriter("pFile.c");
        Scanner sc = new Scanner(input);
        while(sc.hasNextLine())
            {
                String line = sc.nextLine();
                String[] words= line.split(" ");

                for(int i=0; words[i]!=null; i++)
                {
                    if(words[i].contains("//"))
                    {
                        for(int j=i; words[j+1]!=null; j++)
                            i++;
                    }
                    pFile[0].write(words[i]);
                }
            }
    }
}

