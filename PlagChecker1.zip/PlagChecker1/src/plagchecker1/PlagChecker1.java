/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package plagchecker1;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileSystemView;

/**
 *
 * @author saad
 */
public class PlagChecker1{
    
    
    /**
     * @param args the command line arguments
     */
    
    static JLabel l; 
    static Level1Checker case1 = new Level1Checker();
    // a default constructor 
    public static void main(String[] args) {
        int n= Integer.parseInt(JOptionPane.showInputDialog("Enter number of files:"));
        for(int i=0; i<n; i++)
        {
            JFileChooser j= new JFileChooser(FileSystemView.getFileSystemView().getHomeDirectory());
            int returnValue = j.showOpenDialog(null);

		if (returnValue == JFileChooser.APPROVE_OPTION) {
			//File selectedFile
                        case1.inputFile[i] = j.getSelectedFile();
                        try
                        {
                            case1.commentExtractor(case1.inputFile[i]);
                        }
                        catch(IOException IOE)
                        {
                            System.out.println(IOE);
                        }
                        
                        //case1.inputFile[i] = selectedFile;
			//System.out.println(selectedFile.getAbsolutePath());
		}
                
        }
                
    }
    
    
}
