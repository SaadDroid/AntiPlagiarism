/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package plagchecker1;

import java.io.File;
import java.io.FileWriter;

/**
 *
 * @author saad
 */
public class Comparer {
    public File[] inputFile = new File[30];
    public FileWriter[] pFile = new FileWriter[30];
    public int numberOfFiles;
    public boolean isClone;
    
    public boolean CompareFiles(File file1, File file2)
    {
        return true;
    }
}
